import React from 'react';

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* En-tête */}
      <header className="bg-emerald-600 text-white py-6 shadow-lg">
        <h1 className="text-center">
          <span className="block text-2xl md:text-3xl font-semibold mb-2">
            Générateur de cartes de vœux pour l'Aïd
          </span>
          <span className="block text-xl md:text-2xl font-medium" dir="rtl" lang="ar">
            مُنشئ بطاقات تهنئة العيد
          </span>
        </h1>
      </header>

      {/* Publicité sous l'en-tête */}
      <div className="w-full bg-gray-100 p-4 text-center border-b">
        <div className="max-w-[728px] h-[90px] mx-auto bg-gray-200">
          {/* Emplacement AdSense */}
        </div>
      </div>

      {/* Contenu principal avec publicité latérale */}
      <div className="flex-grow flex">
        {/* Zone principale */}
        <main className="flex-grow p-6 flex items-center justify-center">
          <div className="w-full max-w-2xl bg-white rounded-lg shadow-md p-8">
            {/* Contenu du générateur à venir */}
          </div>
        </main>

        {/* Publicité latérale */}
        <aside className="hidden lg:block w-[300px] p-4 bg-gray-50">
          <div className="w-[300px] h-[600px] bg-gray-200">
            {/* Emplacement AdSense */}
          </div>
        </aside>
      </div>

      {/* Publicité bas de page */}
      <div className="w-full bg-gray-100 p-4 text-center">
        <div className="max-w-[728px] h-[90px] mx-auto bg-gray-200">
          {/* Emplacement AdSense */}
        </div>
      </div>

      {/* Pied de page */}
      <footer className="bg-gray-800 text-white py-4 text-center">
        <p className="mb-1">© 2024 - Tous droits réservés</p>
        <p dir="rtl" lang="ar">جميع الحقوق محفوظة - ٢٠٢٤ ©</p>
      </footer>
    </div>
  );
}

export default App;